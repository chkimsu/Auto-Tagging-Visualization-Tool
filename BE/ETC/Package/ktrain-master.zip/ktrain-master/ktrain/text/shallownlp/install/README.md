# shallownlp
Shallow NLP:   easy-to-apply text-analysis utilities for English and Chinese with no GPU required
