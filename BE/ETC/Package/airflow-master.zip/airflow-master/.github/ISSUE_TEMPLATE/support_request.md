---
name: Question or Support request
about: Any questions you might have.
title: ''
labels: invalid
assignees: ''

---

**Do not use issues for support requests or general help queries**

Please ask on one of our mailing lists, or in our Slack channel. See the "Ask a question" section of http://airflow.apache.org/community/

Issues which are not bug reports or feature requests (i.e. "how do I get X working", or "How do I best do X?") will likely be closed without a response.
