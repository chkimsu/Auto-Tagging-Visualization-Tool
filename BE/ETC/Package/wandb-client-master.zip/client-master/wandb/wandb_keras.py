from wandb.keras import WandbCallback
print("DEPRECATED: wandb.wandb_keras is deprecated, use `from wandb.keras import WandbCallback`")


class WandbKerasCallback(WandbCallback):
    pass
