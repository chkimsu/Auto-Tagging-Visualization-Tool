from wandb import magic_impl

magic_impl.magic_install()
